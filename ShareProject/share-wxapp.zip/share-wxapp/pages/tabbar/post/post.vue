<template>
	 <view class="container">
	      <!-- 标题卡片模式 -->
	      <uni-card 
	          title="微服务技术" 
	          mode="title" 
	          :is-shadow="true" 
	          thumbnail="https://img-cdn-qiniu.dcloud.net.cn/uniapp/images/muwu.jpg" 
	          extra="技术没有上限" 
	          note="软件_1851"
	      >
		  微服务技术微服务技术
	      </uni-card>
	    </view>
		
</template>
<script>
export default {
	data() {
		return {
			title:"投稿"
		};
	},
};
</script>
<style>

</style>
