<template>
	<view class="container">
		<view v-if="!user" class="box">
			<img src="https://i.loli.net/2020/10/10/mFxrTZNwPG6CBta.png" class="avatar" />
			<p class="info">登录，享受技术之旅吧！</p>
			<button @click="login">微信账号登录</button>
		</view>
		<view v-else class="box">
			<img :src="user.avatarUrl" class="avatar" />
			<p class="info">{{ user.wxNickname }}</p>
			<p class="info">当前积分：{{ user.bonus }}</p>
			<button @click="logout">退出</button>
		</view>
	</view>
</template>

<script>
import { request } from '@/utils/request';
import { LOGIN_URL } from '@/utils/api';
export default {
	data() {
		return {
			user: null
		};
	},
	onLoad() {
		if (uni.getStorageSync('user')) {
			this.user = uni.getStorageSync('user');
		}
	},
	methods: {
		login() {
			let self = this;
			uni.login({
				provider: 'weixin',
				success: function(loginRes) {
					console.log(loginRes.authResult);
					uni.getUserInfo({
						provider: 'weixin',
						success: infoRes => {
							// console.log('用户昵称为：' + infoRes.userInfo.nickName);
							request(LOGIN_URL, 'POST', {
								wxId: loginRes.authResult.openid,
								wxNickname: infoRes.userInfo.nickName,
								avatarUrl: infoRes.userInfo.avatarUrl
							}).then(res => {
								uni.showToast({
									title: '登录成功'
								});
								console.log(res.data.user);
								self.user = res.data.user;
								uni.setStorageSync('user', res.data.user);
							});
						}
					});
				}
			});
		},
		logout() {
			this.user = null;
			uni.removeStorageSync('user');
		}
	}
};
</script>

<style lang="scss">
.container {
	text-align: center;
	.box {
		margin-top: 20px;
		.avatar {
			width: 150px;
			height: 150px;
			border-radius: 50%;
		}
		.info {
			font-size: 16px;
			margin-bottom: 30px;
		}
	}
}
</style>
